<h1>Contents of the $_GET array</h1>
<p>Using print_r:</p>
<pre>
<?php
  print_r($_GET);
?>
</pre>
<p>Using var_dump:</p>
<pre>
<?php
  var_dump($_GET);
?>
</pre>


