<?php
session_start();
?>
<html>
<head>
</head>
<body>
<h1>Cool Application heading</h1>
<?php 
if(isset($_SESSION['success'])){
?>
	<p>
	<span>Hello</span>
	<span style="color:green "><b><?=$_SESSION['account']?></b></span>
	</p>
<?php
	unset($_SESSION['success']);//why unset
}
	//check if log in
	if(!isset($_SESSION['account'])){ ?>
		<p>please <a href="login.php">log in </a> to start.</p>
	<?php
	}else{?>
	<p>this is where a cool application wold be</p>
	<?php require_once 'home.php';?>
	<p>please <a href="logout.php"> log out </a>when you are done</p>
<?php 
	}?>
</body>
</html>